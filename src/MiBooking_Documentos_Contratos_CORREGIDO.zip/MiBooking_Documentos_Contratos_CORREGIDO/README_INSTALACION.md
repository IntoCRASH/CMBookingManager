# MiBooking — Documentos y contratos

## Qué incluye

- Página **Documentos** para Artista y Gestor.
- Generación únicamente desde cotizaciones `Confirmada` o `Aprobada`.
- Configuración contractual editable por el Artista desde **Perfil**.
- Variables automáticas para datos del Artista, cliente, evento, pagos, producción y jurisdicción.
- Snapshot permanente del contrato para que no cambie cuando se edite el perfil o la cotización.
- PDF A4 generado desde el navegador con el logo de MiBooking, resumen, cláusulas, anexos y firmas.
- Almacenamiento privado del PDF en Supabase.
- Descarga del PDF por Artista o Gestor autorizado.
- Envío por correo mediante Supabase Edge Function + Resend.
- Versiones independientes por cotización: `CTR-NUMERO-V1`, `V2`, etc.

## Orden obligatorio

### 1. Ejecutar la migración SQL

En Supabase > SQL Editor, ejecuta completo:

```text
supabase/10_mibooking_documentos_contratos.sql
```

La migración agrega la configuración contractual a `perfiles_negocio`, crea `contratos`, activa RLS y crea el bucket privado `contratos-pdf`.

### 2. Copiar los archivos

Copia sobre tu proyecto respetando las rutas:

```text
src/App.jsx
src/pages/Perfil.jsx
src/pages/Documentos.jsx
src/pages/Documentos.css
src/lib/profileService.js
src/lib/contratosService.js
src/lib/contratoTemplate.js
src/lib/contratoPdf.js
package.json
```

### 3. Instalar la dependencia PDF

Desde la carpeta principal del proyecto:

```powershell
npm install
```

El `package.json` ya incluye `jspdf`.

### 4. Desplegar la función de correo

Copia:

```text
supabase/functions/enviar-contrato/index.ts
```

Después ejecuta:

```powershell
supabase functions deploy enviar-contrato
```

Configura los secretos, usando el mismo dominio y cuenta de Resend que ya utiliza MiBooking para las invitaciones:

```powershell
supabase secrets set RESEND_API_KEY="TU_API_KEY"
supabase secrets set RESEND_FROM_EMAIL="MiBooking <correo@tudominio.com>"
supabase secrets set APP_PUBLIC_URL="https://tu-app.com"
```

`SUPABASE_URL`, `SUPABASE_ANON_KEY` y `SUPABASE_SERVICE_ROLE_KEY` están disponibles automáticamente dentro del proyecto Supabase.

### 5. Reiniciar

```powershell
npm run dev
```

Actualiza el navegador con `Ctrl + F5`.

## Prueba recomendada

1. Entra como Artista a **Perfil**.
2. Revisa la nueva sección **Configuración contractual** y guarda.
3. Coloca una cotización en estado `Confirmada`.
4. Abre **Documentos**.
5. Pulsa **Generar contrato** y selecciona la cotización.
6. Completa obligatoriamente cédula/RNC, dirección y representante del cliente.
7. Revisa horarios, sets, producción, pagos y condiciones especiales.
8. Pulsa **Generar y descargar PDF**.
9. En el listado, prueba **Descargar PDF**.
10. Después de desplegar la Edge Function, prueba **Enviar por correo**.

## Datos que se congelan

Cada versión conserva:

- Identidad legal y artística.
- Datos bancarios utilizados.
- Cliente y representante.
- Evento, dirección, horarios, formato, músicos y sonido.
- Honorarios, anticipo, saldo y fechas límite.
- Producción, hospitalidad, transporte y hospedaje.
- Jurisdicción, condiciones especiales y anexos.
- Texto final de todas las cláusulas.
- Usuario y fecha de generación.

Una modificación posterior del Perfil o de la cotización no altera un contrato ya generado.

## Nota jurídica

La plantilla combina y reorganiza las cláusulas de los dos contratos de referencia proporcionados. Antes de utilizarla como contrato definitivo con clientes, debe revisarla un abogado habilitado en la República Dominicana, especialmente en materia de cancelación, responsabilidad, impuestos, firma electrónica y jurisdicción.
