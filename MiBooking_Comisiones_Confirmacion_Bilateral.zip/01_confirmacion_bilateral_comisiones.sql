-- ============================================================
-- MIBOOKING — CONFIRMACIÓN BILATERAL DE COMISIONES
--
-- Flujo:
--   pending
--     -> artist_reported  (el Artista informa que pagó)
--     -> manager_reported (el Gestor informa que recibió)
--
--   artist_reported
--     -> settled          (el Gestor confirma recepción)
--
--   manager_reported
--     -> settled          (el Artista confirma el pago)
--
-- Una vez settled, el estado es irreversible.
-- ============================================================

begin;

alter table public.cotizaciones
  add column if not exists
    comision_flujo_estado text
      not null default 'pending',

  add column if not exists
    comision_reportada_at timestamptz,

  add column if not exists
    comision_reportada_by uuid,

  add column if not exists
    comision_reportada_por_rol text,

  add column if not exists
    comision_confirmada_at timestamptz,

  add column if not exists
    comision_confirmada_by uuid,

  add column if not exists
    comision_confirmada_por_rol text;

alter table public.cotizaciones
  drop constraint if exists
    cotizaciones_comision_flujo_estado_check;

alter table public.cotizaciones
  add constraint
    cotizaciones_comision_flujo_estado_check
  check (
    comision_flujo_estado in (
      'pending',
      'artist_reported',
      'manager_reported',
      'settled'
    )
  );

alter table public.cotizaciones
  drop constraint if exists
    cotizaciones_comision_reportada_rol_check;

alter table public.cotizaciones
  add constraint
    cotizaciones_comision_reportada_rol_check
  check (
    comision_reportada_por_rol is null
    or comision_reportada_por_rol in (
      'owner',
      'manager'
    )
  );

alter table public.cotizaciones
  drop constraint if exists
    cotizaciones_comision_confirmada_rol_check;

alter table public.cotizaciones
  add constraint
    cotizaciones_comision_confirmada_rol_check
  check (
    comision_confirmada_por_rol is null
    or comision_confirmada_por_rol in (
      'owner',
      'manager'
    )
  );

create index if not exists
  cotizaciones_workspace_comision_flujo_idx
on public.cotizaciones(
  workspace_id,
  comision_flujo_estado
);

-- Las comisiones que ya figuraban como cobradas/pagadas
-- se conservan como cerradas para no reabrir liquidaciones
-- históricas.
update public.cotizaciones as c
set
  comision_flujo_estado =
    case
      when lower(
        trim(
          coalesce(
            c.comision_estado,
            ''
          )
        )
      ) in (
        'cobrada',
        'pagada',
        'liquidada'
      )
      or c.comision_liquidada_at is not null
        then 'settled'
      else 'pending'
    end,

  comision_reportada_at =
    case
      when lower(
        trim(
          coalesce(
            c.comision_estado,
            ''
          )
        )
      ) in (
        'cobrada',
        'pagada',
        'liquidada'
      )
      or c.comision_liquidada_at is not null
        then coalesce(
          c.comision_liquidada_at,
          c.updated_at,
          now()
        )
      else null
    end,

  comision_reportada_by =
    case
      when lower(
        trim(
          coalesce(
            c.comision_estado,
            ''
          )
        )
      ) in (
        'cobrada',
        'pagada',
        'liquidada'
      )
      or c.comision_liquidada_at is not null
        then c.comision_liquidada_by
      else null
    end,

  comision_reportada_por_rol =
    case
      when lower(
        trim(
          coalesce(
            c.comision_estado,
            ''
          )
        )
      ) in (
        'cobrada',
        'pagada',
        'liquidada'
      )
      or c.comision_liquidada_at is not null
        then c.comision_liquidada_por_rol
      else null
    end,

  comision_confirmada_at =
    case
      when lower(
        trim(
          coalesce(
            c.comision_estado,
            ''
          )
        )
      ) in (
        'cobrada',
        'pagada',
        'liquidada'
      )
      or c.comision_liquidada_at is not null
        then coalesce(
          c.comision_liquidada_at,
          c.updated_at,
          now()
        )
      else null
    end,

  comision_confirmada_by =
    case
      when lower(
        trim(
          coalesce(
            c.comision_estado,
            ''
          )
        )
      ) in (
        'cobrada',
        'pagada',
        'liquidada'
      )
      or c.comision_liquidada_at is not null
        then c.comision_liquidada_by
      else null
    end,

  comision_confirmada_por_rol =
    case
      when lower(
        trim(
          coalesce(
            c.comision_estado,
            ''
          )
        )
      ) in (
        'cobrada',
        'pagada',
        'liquidada'
      )
      or c.comision_liquidada_at is not null
        then c.comision_liquidada_por_rol
      else null
    end
where coalesce(c.comision, 0) > 0;


-- ------------------------------------------------------------
-- LISTADO DE COMISIONES
-- ------------------------------------------------------------

create or replace function
public.get_workspace_commissions(
  p_workspace_id bigint
)
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_user_id uuid := auth.uid();
  v_role text;
  v_result jsonb;
begin
  if v_user_id is null then
    raise exception
      'No hay una sesión activa.';
  end if;

  select wm.role
  into v_role
  from public.workspace_members as wm
  where wm.workspace_id =
      p_workspace_id
    and wm.user_id =
      v_user_id
    and wm.status =
      'active'
  limit 1;

  if v_role not in (
    'owner',
    'manager'
  ) then
    raise exception
      'No tienes acceso activo a este Artista.';
  end if;

  with commission_base as (
    select
      c.*,

      case
        when c.vendedor_id is not null
          then c.vendedor_id

        when exists (
          select 1
          from public.workspace_members
            as creator_membership
          where
            creator_membership.workspace_id =
              c.workspace_id
            and creator_membership.user_id =
              c.created_by
            and creator_membership.role =
              'manager'
        )
          then c.created_by

        else null
      end as gestor_user_id_resuelto

    from public.cotizaciones as c
    where c.workspace_id =
        p_workspace_id
      and coalesce(
        c.comision,
        0
      ) > 0
  ),

  visible_rows as (
    select
      cb.id::text as cotizacion_id,
      cb.numero::text as numero,
      cb.workspace_id,
      w.nombre::text as artista_nombre,

      cb.gestor_user_id_resuelto
        as gestor_user_id,

      coalesce(
        nullif(
          trim(gp.nombre),
          ''
        ),
        gu.email::text,
        'Gestor no identificado'
      ) as gestor_nombre,

      coalesce(
        gu.email::text,
        ''
      ) as gestor_email,

      coalesce(
        nullif(
          trim(cl.nombre),
          ''
        ),
        'Cliente'
      ) as cliente_nombre,

      cb.nombre_evento,
      cb.tipo_evento,
      cb.venue,
      cb.fecha_evento,
      cb.total,
      cb.comision,
      cb.comision_porcentaje_snapshot,

      coalesce(
        cb.comision_flujo_estado,
        case
          when lower(
            trim(
              coalesce(
                cb.comision_estado,
                ''
              )
            )
          ) in (
            'cobrada',
            'pagada',
            'liquidada'
          )
            then 'settled'
          else 'pending'
        end
      ) as workflow_status,

      cb.comision_reportada_at,
      cb.comision_reportada_by,
      cb.comision_reportada_por_rol,

      cb.comision_confirmada_at,
      cb.comision_confirmada_by,
      cb.comision_confirmada_por_rol,

      cb.comision_liquidada_at,
      cb.comision_liquidada_by,
      cb.comision_liquidada_por_rol,

      cb.created_at

    from commission_base as cb

    join public.workspaces as w
      on w.id =
        cb.workspace_id

    left join public.profiles as gp
      on gp.id =
        cb.gestor_user_id_resuelto

    left join auth.users as gu
      on gu.id =
        cb.gestor_user_id_resuelto

    left join public.clientes as cl
      on cl.id =
        cb.cliente_id

    where
      v_role = 'owner'
      or (
        v_role = 'manager'
        and cb.gestor_user_id_resuelto =
          v_user_id
      )
  )

  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'cotizacion_id',
          vr.cotizacion_id,

        'numero',
          vr.numero,

        'workspace_id',
          vr.workspace_id,

        'artista_nombre',
          vr.artista_nombre,

        'gestor_user_id',
          vr.gestor_user_id,

        'gestor_nombre',
          vr.gestor_nombre,

        'gestor_email',
          vr.gestor_email,

        'cliente_nombre',
          vr.cliente_nombre,

        'nombre_evento',
          vr.nombre_evento,

        'tipo_evento',
          vr.tipo_evento,

        'venue',
          vr.venue,

        'fecha_evento',
          vr.fecha_evento,

        'total',
          vr.total,

        'comision',
          vr.comision,

        'comision_porcentaje',
          vr.comision_porcentaje_snapshot,

        'workflow_status',
          vr.workflow_status,

        'settlement_status',
          case
            when vr.workflow_status =
              'settled'
              then 'settled'
            else 'pending'
          end,

        'initiated_at',
          vr.comision_reportada_at,

        'initiated_by',
          vr.comision_reportada_by,

        'initiated_by_role',
          vr.comision_reportada_por_rol,

        'confirmed_at',
          vr.comision_confirmada_at,

        'confirmed_by',
          vr.comision_confirmada_by,

        'confirmed_by_role',
          vr.comision_confirmada_por_rol,

        'settled_at',
          vr.comision_liquidada_at,

        'settled_by',
          vr.comision_liquidada_by,

        'settled_by_role',
          vr.comision_liquidada_por_rol
      )
      order by
        vr.fecha_evento desc
          nulls last,
        vr.created_at desc
    ),
    '[]'::jsonb
  )
  into v_result
  from visible_rows as vr;

  return v_result;
end;
$$;


-- ------------------------------------------------------------
-- AVANZAR EL FLUJO
-- No recibe un estado arbitrario: el servidor decide la
-- única transición permitida según el rol y el estado actual.
-- ------------------------------------------------------------

create or replace function
public.advance_workspace_commission_status(
  p_workspace_id bigint,
  p_cotizacion_id text
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user_id uuid := auth.uid();
  v_role text;
  v_manager_user_id uuid;
  v_state text;
  v_new_state text;
  v_now timestamptz := now();
begin
  if v_user_id is null then
    raise exception
      'No hay una sesión activa.';
  end if;

  select wm.role
  into v_role
  from public.workspace_members as wm
  where wm.workspace_id =
      p_workspace_id
    and wm.user_id =
      v_user_id
    and wm.status =
      'active'
  limit 1;

  if v_role not in (
    'owner',
    'manager'
  ) then
    raise exception
      'No tienes permiso para actualizar esta comisión.';
  end if;

  select
    case
      when c.vendedor_id is not null
        then c.vendedor_id

      when exists (
        select 1
        from public.workspace_members
          as creator_membership
        where
          creator_membership.workspace_id =
            c.workspace_id
          and creator_membership.user_id =
            c.created_by
          and creator_membership.role =
            'manager'
      )
        then c.created_by

      else null
    end,

    coalesce(
      c.comision_flujo_estado,
      case
        when lower(
          trim(
            coalesce(
              c.comision_estado,
              ''
            )
          )
        ) in (
          'cobrada',
          'pagada',
          'liquidada'
        )
          then 'settled'
        else 'pending'
      end
    )

  into
    v_manager_user_id,
    v_state

  from public.cotizaciones as c
  where c.workspace_id =
      p_workspace_id
    and c.id::text =
      trim(p_cotizacion_id)
    and coalesce(
      c.comision,
      0
    ) > 0
  for update;

  if not found then
    raise exception
      'La comisión indicada no existe en este Artista.';
  end if;

  if v_manager_user_id is null then
    raise exception
      'No fue posible identificar al Gestor de esta comisión.';
  end if;

  if (
    v_role = 'manager'
    and v_manager_user_id is distinct
      from v_user_id
  ) then
    raise exception
      'Esta comisión pertenece a otro Gestor.';
  end if;

  if v_state = 'settled' then
    raise exception
      'Esta comisión ya fue confirmada definitivamente y no puede modificarse.';
  end if;

  if v_state = 'pending' then
    v_new_state :=
      case
        when v_role = 'owner'
          then 'artist_reported'
        else 'manager_reported'
      end;

    update public.cotizaciones as c
    set
      comision_flujo_estado =
        v_new_state,

      comision_estado =
        'Pendiente',

      comision_reportada_at =
        v_now,

      comision_reportada_by =
        v_user_id,

      comision_reportada_por_rol =
        v_role,

      comision_confirmada_at =
        null,

      comision_confirmada_by =
        null,

      comision_confirmada_por_rol =
        null,

      comision_liquidada_at =
        null,

      comision_liquidada_by =
        null,

      comision_liquidada_por_rol =
        null,

      updated_at =
        v_now

    where c.workspace_id =
        p_workspace_id
      and c.id::text =
        trim(p_cotizacion_id);

    return jsonb_build_object(
      'ok', true,
      'cotizacion_id',
        trim(p_cotizacion_id),
      'workflow_status',
        v_new_state,
      'action',
        'reported',
      'changed_by',
        v_user_id,
      'changed_by_role',
        v_role
    );
  end if;

  if (
    v_state = 'artist_reported'
    and v_role <> 'manager'
  ) then
    raise exception
      'El pago ya fue informado. Ahora debe confirmarlo el Gestor.';
  end if;

  if (
    v_state = 'manager_reported'
    and v_role <> 'owner'
  ) then
    raise exception
      'El cobro ya fue informado. Ahora debe confirmarlo el Artista.';
  end if;

  if v_state not in (
    'artist_reported',
    'manager_reported'
  ) then
    raise exception
      'El estado actual de esta comisión no permite continuar.';
  end if;

  update public.cotizaciones as c
  set
    comision_flujo_estado =
      'settled',

    comision_estado =
      'Cobrada',

    comision_confirmada_at =
      v_now,

    comision_confirmada_by =
      v_user_id,

    comision_confirmada_por_rol =
      v_role,

    comision_liquidada_at =
      v_now,

    comision_liquidada_by =
      v_user_id,

    comision_liquidada_por_rol =
      v_role,

    updated_at =
      v_now

  where c.workspace_id =
      p_workspace_id
    and c.id::text =
      trim(p_cotizacion_id);

  return jsonb_build_object(
    'ok', true,
    'cotizacion_id',
      trim(p_cotizacion_id),
    'workflow_status',
      'settled',
    'action',
      'confirmed',
    'changed_by',
      v_user_id,
    'changed_by_role',
      v_role,
    'confirmed_at',
      v_now
  );
end;
$$;


-- ------------------------------------------------------------
-- DESACTIVAR EL RPC ANTIGUO
-- Elimina la ruta que permitía volver una comisión a Pendiente.
-- ------------------------------------------------------------

drop function if exists
public.set_workspace_commission_status(
  bigint,
  text,
  boolean
);


revoke all
on function
public.get_workspace_commissions(
  bigint
)
from public;

revoke all
on function
public.advance_workspace_commission_status(
  bigint,
  text
)
from public;

grant execute
on function
public.get_workspace_commissions(
  bigint
)
to authenticated;

grant execute
on function
public.advance_workspace_commission_status(
  bigint,
  text
)
to authenticated;

commit;
